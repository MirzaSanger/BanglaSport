BanglaSport Android v1 prototype

Open this project in Android Studio and build:
Build > Build Bundle(s) / APK(s) > Build APK(s)

This app is a sports entertainment prototype. It uses no real-money betting, deposits, withdrawals, or cash-out. Match data is placeholder until a licensed/authorized sports-data API is connected.

Revenue-ready areas: advertising, premium subscriptions, sponsorships.

Recommended next step: connect a legitimate cricket/football data provider and add backend accounts, analytics, notifications, and a compliant ad/subscription system.

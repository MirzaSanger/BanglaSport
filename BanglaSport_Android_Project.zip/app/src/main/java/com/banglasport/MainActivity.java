package com.banglasport;

import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    LinearLayout content; int green=Color.rgb(0,110,70);
    String[] teams={"🇧🇩 Bangladesh","🇮🇳 India","🇦🇺 Australia","🇬🇧 England"};
    @Override public void onCreate(Bundle b){super.onCreate(b); showHome();}
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(20,35,29)); t.setPadding(16,12,16,12); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    void base(String title){
      LinearLayout all=new LinearLayout(this); all.setOrientation(LinearLayout.VERTICAL); all.setBackgroundColor(Color.rgb(246,249,247));
      TextView head=tv("🏆 "+title,22); head.setTextColor(Color.WHITE); head.setTypeface(null,1); head.setBackgroundColor(green); head.setPadding(18,22,18,22); all.addView(head);
      content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); ScrollView sv=new ScrollView(this); sv.addView(content); all.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
      LinearLayout nav=new LinearLayout(this); nav.setBackgroundColor(Color.WHITE);
      String[] ns={"⌂ Home","⚽ Matches","🔮 Predict","🏆 Rank","👤 Profile"};
      for(String n:ns){Button x=btn(n); nav.addView(x,new LinearLayout.LayoutParams(0,60,1)); if(n.contains("Home"))x.setOnClickListener(v->showHome()); if(n.contains("Matches"))x.setOnClickListener(v->showMatches()); if(n.contains("Predict"))x.setOnClickListener(v->showPredict()); if(n.contains("Rank"))x.setOnClickListener(v->showRank()); if(n.contains("Profile"))x.setOnClickListener(v->showProfile());}
      all.addView(nav); setContentView(all);
    }
    void showHome(){base("BanglaSport"); content.addView(tv("🇧🇩 বাংলাদেশের স্পোর্টস হাব",24)); content.addView(tv("Football • Cricket • Live Scores • Predictions",15));
      content.addView(tv("🔥 Today’s Highlights",19)); content.addView(tv("🏏 Bangladesh vs India\nToday • 7:30 PM\nLive score will appear here when a sports-data API is connected.",16));
      content.addView(tv("⚽ Premier League\nMatch centre • statistics • team news",16));
      Button p=btn("🔮 Play Prediction — Earn Points"); p.setOnClickListener(v->showPredict()); content.addView(p);
      content.addView(tv("💰 Revenue model: ads + premium subscription + sponsorships. No real-money betting or cash-out.",13));
    }
    void showMatches(){base("Matches"); content.addView(tv("🏏 Cricket",20)); for(String x:new String[]{"Bangladesh vs India — Today 7:30 PM","Australia vs England — Tomorrow 3:00 PM"}) content.addView(tv("• "+x,16)); content.addView(tv("⚽ Football",20)); for(String x:new String[]{"Liverpool vs Arsenal — 10:00 PM","Barcelona vs Real Madrid — 1:00 AM"}) content.addView(tv("• "+x,16));}
    void showPredict(){base("Prediction"); content.addView(tv("🔮 Predict for points",23)); content.addView(tv("Choose the winner. This uses virtual points only — no money or cash prizes.",14)); RadioGroup g=new RadioGroup(this); for(String x:teams){RadioButton r=new RadioButton(this);r.setText(x);r.setTextSize(16);r.setPadding(10,8,10,8);g.addView(r);} content.addView(g); Button b=btn("Submit Prediction"); b.setOnClickListener(v->{Toast.makeText(this,"Prediction saved! +10 virtual points",Toast.LENGTH_SHORT).show();}); content.addView(b);}
    void showRank(){base("Leaderboard"); content.addView(tv("🏆 Top Players",22)); int i=1; for(String x:new String[]{"Rahim — 12,450 pts","Sadia — 11,820 pts","Tanvir — 10,940 pts","Nusrat — 9,780 pts"})content.addView(tv(i+++". "+x,17));}
    void showProfile(){base("Profile"); content.addView(tv("👤 Guest User",23)); content.addView(tv("Virtual Points: 1,250\nPredictions: 38\nRank: #124",16)); Button b=btn("⭐ Upgrade to Premium"); b.setOnClickListener(v->Toast.makeText(this,"Premium module ready for payment integration.",Toast.LENGTH_SHORT).show()); content.addView(b);}
}

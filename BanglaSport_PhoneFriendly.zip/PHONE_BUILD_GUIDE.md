# BanglaSport — Phone-only APK build

You can build this project from an Android phone using GitHub's browser and GitHub Actions.

1. Create/sign in to a GitHub account.
2. Create a new repository, e.g. `BanglaSport`.
3. Upload the contents of this project (not the ZIP itself).
4. Open the repository's **Actions** tab.
5. Select **Build BanglaSport APK**.
6. Tap **Run workflow**.
7. Wait for the workflow to finish.
8. Open the completed workflow run and download the artifact named `BanglaSport-debug-apk`.
9. Extract the downloaded artifact and install `app-debug.apk` on your phone.

This version contains no real-money betting, deposits, withdrawals, or cash-out.
The sports fixtures and scores are placeholder data until a legitimate sports-data provider is connected.
